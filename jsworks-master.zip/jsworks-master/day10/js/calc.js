// 덧셈 프로그램
let n1 = parseInt(prompt("첫 번째 숫자를 입력하세요."));
let n2 = parseInt(prompt("두 번째 숫자를 입력하세요."));
let sum_v = 0;

// 연산
// sum_v = parseInt(n1) + parseInt(n2);
sum_v = n1 + n2;

document.write("두 수의 합 : " + sum_v);